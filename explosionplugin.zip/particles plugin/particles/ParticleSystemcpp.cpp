#include "ParticleSystem.h"
#include <windows.h>
#include <fstream>

// Constructors
ParticleSystem::ParticleSystem()
{
}

ParticleSystem::~ParticleSystem()
{
	delete[] m_ParticleBuff;
}

// The main function for updating the particles position and velocity over time
void ParticleSystem::Update(Particle a_arr[], float dt)
{
	for (unsigned int i = 0; i < m_MaxSize; i++)
	{
		/*
		1. Subtract the particles current position and the target position to get the vector between the two.
		2. Normalize to get just the direction.
		3. Multiply the direction by the gravity force to add magnitude.
		4. Multiply by the change in time
		5. Subtract by the old velocity to get the new velocity  */ 
		a_arr[i].Vel = subtract(a_arr[i].Vel, multiply(multiply(Normalize(subtract(a_arr[i].Pos, m_targetPos)), m_GravityPull), dt));

		// Add the new velocity to the position to get the updated position
		a_arr[i].Pos = add(a_arr[i].Pos, a_arr[i].Vel);

		if (a_arr[i].lifeSpan != 0)
		{
			a_arr[i].lifeSpan -= dt;
		}

	}
}

///////// Vector Math Functions //////////////
Vec multiply(Vec v, float scalar)
{
	Vec l_v;
	l_v.x = v.x * scalar;
	l_v.y = v.y * scalar;
	l_v.z = v.z * scalar;
	return l_v;
}
float Length(Vec v)
{
	return sqrtf((v.x * v.x) + (v.y * v.y) + (v.z * v.z));
}
Vec Normalize(Vec v)
{
	Vec output;
	float output_Length = Length(v);
	if (output_Length != 0)
	{
		output.x = v.x / output_Length;
		output.y = v.y / output_Length;
		output.z = v.z / output_Length;
	}
	return output;
}
Vec subtract(Vec v, Vec v2)
{
	Vec output;
	output.x = v.x - v2.x;
	output.y = v.y - v2.y;
	output.z = v.z - v2.z;

	return output;
}
Vec add(Vec v, Vec v2)
{
	Vec output;
	output.x = v.x + v2.x;
	output.y = v.y + v2.y;
	output.z = v.z + v2.z;
	return output;
}


