#pragma once
#include <cmath>
extern "C"
{
	// Vector Struct to use for xyz values
	__declspec(dllexport) struct Vec 
	{
		float x, y, z;
	};
	
	// The particle struct itself, position and velocity
	__declspec(dllexport) struct Particle
	{
		Vec Pos;
		Vec Vel;
		float lifeSpan;
	};
}

// Math functions for vector math
float Length(Vec v);
Vec Normalize(Vec v);
Vec subtract(Vec v, Vec v2);
Vec add(Vec v, Vec v2);
Vec multiply(Vec v, float scalar);


class ParticleSystem
{
public:
	ParticleSystem();
	~ParticleSystem();
	
	Particle *m_ParticleBuff;
	
	// Updates the particles velocity and position
	void Update(Particle a_arr[], float dt);
	
	// Max number of particles
	int m_MaxSize;
	
	// Where the particles are heading
	Vec m_targetPos;
	
	// Spread of particles from eachother
	float m_spawnDistance = 3;
	
	// Target's pull on the particle
	float m_GravityPull = 10;

	// Life length of the particle
	float m_lifeTime = 1;
	
};