#pragma once
#include "ParticleSystem.h"

extern "C"
{
	__declspec(dllexport) void initSystem();
	__declspec(dllexport) void initialize(Particle *p, int Size, float spawnDistance, bool lockZ, float distanceRan, float angleRan, float lifeSpanMax, float lifeSpanMin);
	__declspec(dllexport) void updateTargetPos(float x, float y, float z);
	__declspec(dllexport) void updateParticle(Particle *p, float dt);
	__declspec(dllexport) void updateAttraction(float f);
	__declspec(dllexport) void destroyParticles();
}