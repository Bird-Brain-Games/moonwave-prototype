#include "Wrapper.h"
#include "ParticleSystem.h"
#include <windows.h>
#include <fstream>
#include <ctime>

ParticleSystem *particleSystem;

// Initiallize the particle system
void initSystem() 
{
	particleSystem = new ParticleSystem();
	srand((unsigned)time(0));
}

void initialize(Particle *p, int numParticles, float spawnDistance, bool lockZ, float distanceRan, float angleRan, float lifeSpanMax, float lifeSpanMin)
{

	particleSystem->m_spawnDistance = spawnDistance;
	
	for (int i = 0; i < numParticles; i++)
	{
		
		p[i].lifeSpan = static_cast <float> (rand()) / static_cast <float> (RAND_MAX / lifeSpanMax - lifeSpanMin);

		float randomAngle = static_cast <float> (rand()) / static_cast <float> (RAND_MAX/angleRan);
		float randomDistance = static_cast <float> (rand()) / static_cast <float> (RAND_MAX / distanceRan);

		float angle = (2 * 3.14 / numParticles) * i;
		//float rad = ang * 3.14 / 180;
		// TODO: Change this so they spawn in a circle around the shield
		p[i].Pos.x = particleSystem->m_targetPos.x + (randomDistance + spawnDistance) * cos(angle + randomAngle);
		p[i].Pos.y = particleSystem->m_targetPos.y + (randomDistance + spawnDistance) * sin(angle + randomAngle);
		p[i].Vel.x = cos(angle + randomAngle);
		p[i].Vel.y = sin(angle + randomAngle);

		// Since our game is 2.5D, added functionallity to lock the Z
		if (lockZ)
		{
			p[i].Pos.z = particleSystem->m_targetPos.z;
			p[i].Vel.z = 0;
		}
		else
		{
			p[i].Pos.z = particleSystem->m_targetPos.z + (randomDistance + spawnDistance) * tan(angle + randomAngle);
			p[i].Vel.z = tan(angle + randomAngle);
		}
		
	}
	particleSystem->m_MaxSize = numParticles;
}

void updateTargetPos(float x,float y, float z)
{
	particleSystem->m_targetPos.x = x;
	particleSystem->m_targetPos.y = y;
	particleSystem->m_targetPos.z = z;
}

void updateParticle(Particle *p, float dt)
{
	particleSystem->Update(p, dt);
	std::ofstream outFile;
	outFile.open("outFile.txt", std::ios_base::app);
	outFile << dt << " " << particleSystem->m_GravityPull << std::endl;
}

void updateAttraction(float f) 
{
	particleSystem->m_GravityPull = f;
}



void destroyParticles()
{
	particleSystem->~ParticleSystem();
}
